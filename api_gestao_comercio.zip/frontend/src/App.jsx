import { useState } from "react";

export default function App() {
  const [barcode, setBarcode] = useState("");

  const handleKeyPress = (e) => {
    if (e.key === "Enter") {
      alert("Código escaneado: " + barcode);
      setBarcode("");
    }
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>Gestão de Comércio</h1>
      <input
        autoFocus
        placeholder="Escaneie o código de barras..."
        value={barcode}
        onChange={(e) => setBarcode(e.target.value)}
        onKeyPress={handleKeyPress}
      />
    </div>
  );
}